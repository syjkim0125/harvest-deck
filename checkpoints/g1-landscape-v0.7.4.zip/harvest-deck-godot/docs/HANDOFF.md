# v0.7.4 — 명중 이후 시간에 맞춘 피드백 / 2026-11-17 KST

최신 main 612f5cd와 Library ZIP version8(c3a53ad3856107e0d7ced5fa96bd8c4faae5543a845a428177efba40af8e9774)을 새로 읽어 병합.
main의 v0.7.3 가시적 타격 수정/130검사/과일 해금과 ZIP의 추적 도구·관찰기록·비교 체크포인트를 보존.
기존 편안함 기준은 checkpoints/g1-comfort-v0.7.1.zip에 유지. 최근 실제 대화에서 흔들림이 안 보인다는 후속 요청으로 이미 배포된 main 설정을 수용했으며 이번에 강도를 다시 높이지 않는다.

## 실제 버그 및 수정
기존: simulate가 프레임 내부 여러 번 명중을 처리한 뒤 impact.step(delta)로 전체 프레임 시간을 감쇠.
프레임 끝의 새 명중도 프레임 처음부터 발생한 것처럼 나이를 먹어, 30/60/120Hz의 같은 시점 진폭이 다르고 긴 프레임에서는 마지막 명중까지 사라짐.
수정: 기존 120Hz 이하 simulate_slice 시작마다 이전 펄스 시간을 전진시킨 후 실제 명중을 처리.
카메라 출력/리플레이는 feedback_offset()으로 읽기만 하므로 이중 시간 진행 없음.
이 변경만 적용하면 기존보다 최대 출력이 커지는 것을 리플레이로 발견해 화면 출력 벡터를 이전60Hz 최고16/3≈5.333px로 제한.
이는 연구 최적값/원본 계측치가 아니라 강도 증가를 막는 설계 안전상한이다. 내부8px/100ms·이동360/s·105ms절삭은 main 값 보존.
M/1 OFF, pause/reset/focus-out, 헛스윙, 다수 명중 비누적, 판정과 반동 분리 유지. 전역 hit-stop 추가 없음.

## 검증
Godot4.6.3:
- godot --headless --editor --import --quit: PASS
- godot --headless --script tests/run.gd: 134 checks / 0 failures
- 신규3회귀는 변경전133중3실패(pulse-clock-before.txt), 수정후모두통과. 출력상한회귀1개 추가.
- godot --headless --script tests/feel_replay.gd: 5조건18초/38명중/재고26/판매4/회수20 유지. 흔들림OFF0, ON최대5.333px.
- godot --headless --quit-after 120: PASS
- godot --headless --export-release Web ../web/index.html: FAIL — 현재환경에 4.6.3 web_nothreads_debug/release.zip export templates 없음. 게임 스크립트 오류와 구분.
- godot --display-driver x11 --quit-after 10: X11 display 없음 / Wayland 연결 실패. 실제 데스크톱 렌더·이번 조작·청음 미확인.

원본 영상과 리포트를 최신 ID에서 다시 가져옴. reference_tracking.py 재실행으로 기존18샘플 추적과 일치 확인.
새로운 원본 진폭·공격주기를 계측한 것은 아님. 원본 고유 에셋/오디오를 게임에 추출하지 않음.
손맛·가독성·조작성·피로감 인간평점 및 모바일/Mac/GPU성능은 미검증. 자동검사는 원본 동등성 증거가 아니다.

## 저장소/배포 상태
main 읽기/fetch 정상. 로컬통합커밋5c1b38f 작성 후 push는 HTTPS 인증정보 없음(could not read Username, terminal prompts disabled)으로 실패. 접근제한 우회/대체계정 시도 없음. 원격 main/Pages는 변경되지 않았고 v0.7.3 유지.

## 다음
G1 세로 화면/카메라 구도/도형 아트의 차이를 실제 렌더와 원본 영상으로 비교. G2~5 신규확장 보류.
원격과 ZIP을 각각 확인해 병합했고 보존 체크포인트에 main-v0.7.3-612f5cd.zip 추가.
동일 ZIP은 expected_current_version=8로만 교체한다. 충돌 시 최신판 병합 필요.

---

# Current: v0.7.2 — cadence / comfort / merged source

2026-11-17 KST. 최신 ZIP version7(SHA256 8cf7c3ad38faeb79e650c2b3ce4669d1fa8e761954c2280481074b7207e92f08)을 새로 가져와 main 7a4524140af3faa3681c0d54d5381096ccb7ad9a와 대조.


## 이번 실제 변경
- simulate를 최대1/120초 구간으로 나눠 이동·충돌·절삭·가공을 함께 진행한다.
  이전에는 delta가105ms보다 클 때 한 번만 절삭하고 음수cooldown을 남겼다.
  0.5초 입력은 이전1회→수정5회, 다음1/120초에 몰아치는 공격 없음.
- 5/30/60/120Hz의2초 정지절삭20회 및 이동 중 대상통과 결과 일치 확인.
  물리/로직 검사이며 실제 GPU5fps 쾌적함 보장은 아님. 시뮬레이션을 전역정지하지 않는다.
- main의 .github/workflows/web.yml/.gitignore/export 설정 보존, ZIP의 과일해금·HUD·이동360·짧은1.5px 펄스 보존.
  비교체크포인트 g1-comfort-v0.7.1.zip / main-v0.6-7a452414.zip 추가. 기존 체크포인트 유지.
- 원본9.300~10.067초24프레임 재관찰, 관찰과 추정/설계값을 reference-events-30fps.json에 분리.
  9.400초 밝은반응→9.567초 가까운대상 소멸의 화면창은 약167ms.
  겹친 입자·카메라 때문에 명중간격/체력/원작kill시간으로 사용하지 않음. 공격105ms는 유지.

## 명령 / 실제 결과
Godot4.6.3 프로젝트루트:
- godot --headless --editor --import --quit : PASS
- godot --headless --script tests/run.gd : 127 checks / 0 failures
- godot --headless --script tests/feel_replay.gd : 5조건 모두18초/38명중/재고26/판매4/회수20; 흔들림0 또는최대0.844px
- godot --headless --quit-after 120 : PASS
- godot --headless --export-release Web ../web/index.html : PASS(로컬 빌드, 배포 아님)
변경전추가회귀 126중2실패를 docs/cadence-before.txt에 보존. 수정후이동통과1개추가127통과.
실제창 터미널명령: godot --path /workspace/scratch/20439e58e06d/run09/harvest-deck-godot
새창20971523에서 M true, W1.1초 이동→RAW/MIX/READY 증가, S0.25초 후 파란응대링 진행 확인.
포커스아웃 pause 발생 후 P 재개도 관찰. 실제청음 없음: ALSA장치없음→Dummy fallback.

## 저장 / 원격 장애
같은LibraryZIP에 expected_current_version=7로 교체. 충돌이면 최신판을 다시 읽고 병합하며 무가드덮어쓰기 금지.
GitHub create_blob 재시도는403 Resource not accessible by integration. main/Pages 미반영.
권한 우회/다른 계정 시도 없음. 이번에는 기존에 차단된 브라우저 업로드를 반복하지 않음.
main 변경을 잃지 않도록 원격파일해시 대조 및 체크포인트 보존. Sites는 변경하지 않음.

## 미검증 / 다음
사용자 편안함·인간손맛·청음·원본동등성·모바일/Mac/GPU성능 미검증.
새 과일해금의 실제구매 플레이는 여전히 미검증(로직은 회귀검사).
다음: 원본 다구간 캐릭터폭/카메라 추적과 절삭명중을 분리해 비교하고, 아트/세로화면 시점 접근.
공격주기·흔들림 강도를 추정만으로 올리지 않음. G1 우선, G3~5 신규기능은 보류.
접근복구 시 main을 새로 읽고 병합→CI→Pages실제플레이 확인. 재현100%/완료 선언 금지.

---

# Current: v0.7.1 — movement / comfort

과일 해금v0.7 보존. 이동360/s, 비누적 최대1.5px/66.7ms, M키OFF.
docs/FEEL_TUNING.md 참고. 원본100% 일치 미완료.
main은v0.6이며 Github 쓰기403/브라우저 앱설정 차단으로 업로드·배포 미완료.
다음 실행은 main과 이ZIP을 병합한 뒤 검증·배포하며 G1을 우선한다.

---

# Handoff — v0.7 / 2026-11-17 KST

## 기준과 동시 변경 보호
Library libfile_e5fb49d15230819192d425860e2c9edd를 새로 가져옴.
입력 current_version_number=5, SHA256 91c8eb16095ca6c1c761809b58e36906e7bd09c8737dffcaa80b61698a82ceb0.
같은 ZIP에 expected_current_version=5로 교체하며 충돌 시 덮어쓰지 않는다.
checkpoints/g1-v0.1.zip 유지, 두 구역 모두 열린 이전 버전은 checkpoints/g2-v0.6.zip 추가.
이번 기준 ZIP에는 웹 export 설정이 없다. 별도 저장소/웹 배포 작업과 합치거나 배포 성공을 주장하지 않음.
Sites 비교물/저장소 변경 없음. 다음에 저장소 작업 시 최신 remote를 읽고 별도로 변경 통합해야 함.

## 실제 구현
- 노란 과일(kind1) 구역을 회수 지갑 $50로 해금. 기본 녹색(kind0)은 항상 열림.
- G키/CanvasLayer 버튼/호박색 패드(1020,440), 반경80 미만에서 구매.
- 비용은 production.spent_cash에 기록, 미회수대금·부족금액·pause·먼거리·중복 구매 방지.
- 잠긴 과일은 표시/절삭/보상/재생성 시계 대상에서 제외. 해금 시 원래 시드 위치 그대로 활성화.
- 생산 모델 deposit은 이미 보유한 유효 kind0/1을 받는다. 해금은 수확 권한이며 기존 재고를 몰수하는 규칙이 아니다.
- 수확→납품→가공→판매→회수에서 kind1 및 총량 보존, reset은 해금/비용 포함 새 게임으로 복구.
- 녹색 과일 12개 판매→현금60 회수→해금50 구매→잔액10 검증. 직원/강화 구매 선행 필수 아님.
- 버그 수정: 3줄 status Label 실제 최소높이66으로 y46..112인데 기존 버튼 y79부터 겹침.
  버튼 y116/HUD150으로 분리. 새 검사 최초 114개 중1개실패(첫 y108안), 실제 높이 확인 후 수정하여 모두 통과.
  늘어난 HUD에 맞춰 상점 카메라 수직여백150→180. 기존 고객 머리/응대 가장자리 검사 유지.

## 명령과 결과
프로젝트 루트에서 Godot4.6.3:
- godot --headless --path . --editor --import --quit : PASS
- godot --headless --path . --script tests/run.gd : 114 checks / 0 failures
- godot --headless --path . --script tests/feel_replay.gd : 5조건 실행 완료
- godot --headless --path . --quit-after 120 : PASS
로그 docs/import-output.txt,test-output.txt,replay-output.txt,smoke-output.txt.
기존99개를 변경 전/해금 구현 후 통과 확인. 신규15개는 잠금/비용/초기화/생산연결/HUD 배치.
5조건 모두 18초/명중38/재고26/판매4/회수20. 흔들림 OFF0, ON최대벡터9.153px.
이전 명중39에서38로 감소: 잠긴 kind1의 경계1타격 제외. 수확/판매/회수 결과 동일.
동일 효과 조건끼리 비교하며 이전 버전과 공격 수를 억지로 동일하게 맞추지 않음.

## 실제 표시와 미검증
이번 UI는 기존 v0.6 창이 열린 상태. 파일 관리자에서 새 run07 프로젝트 경로 열기를 시도했으나
표시 상태가 /workspace에 머물렀고 새 Godot 프로젝트 로드/실행을 확인하지 못함.
따라서 v0.7 실제 창 해금/버튼 겹침 해소를 확인했다고 주장하지 않음.
키/버튼은 코드로 연결되었으며 구매 함수와 상태/HUD 경계는 자동 검증.
headless 머신 DISPLAY 미설정, xvfb-run 없음. 이전 GUI 장애를 이유로 개발 중단하지 않음.
원본 이번 추가 측정 없음. 청음·주관 손맛·폰/Mac/GPU성능·원본 동등성 미검증.
테스트 수는 손맛의 증명이 아님. 고정75초실패/재고초기화 규칙 추가 없음.

## 다음
1. 최신 ZIP 가드 확인. v0.7 새 프로젝트를 실제 창에서 열어 현금50 회수→G/버튼 구매→노란 과일 수확/납품 확인.
2. G1 원본30fps 다구간 추적/절삭 주기/카메라 추적과 진동 분리. 청음·동일 경로 사람 평가 필요.
3. G2 구현 목록은 해금까지 연결했으나 새 UI 플레이 확인 전 IN_PROGRESS 유지.
4. G3 전환 전 기본형 checkpoints/g2-v0.6.zip 보존. G1 미검증을 DONE으로 바꾸지 않음.
