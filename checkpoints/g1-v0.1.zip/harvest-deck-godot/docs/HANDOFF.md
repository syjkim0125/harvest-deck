# Handoff — v0.1 / 2026-11-17 KST

## Source of truth

이 폴더를 담은 `harvest-deck-godot.zip`의 최신 저장본. 레포는 아직 없음.
Godot 4.6.3.stable.official.7d41c59c4에서 검증.
이전 비공개 웹 프로토타입은 별도 비교물이며 현재 개발 대상은 Godot이다.

## 실제 변경

- 외부 의존성 없는 Godot 프로젝트 및 GDScript 구현.
- 기본 입력/경계, 자동 체인쏘우 절삭, 2종 과일·3회 피격·재생성.
- 실제 명중 이벤트 → 제한된 화면 흔들림, 반동/flash, 합성 타격음.
- 카메라 추적과 offset 분리. CanvasLayer HUD는 카메라 변환에서 분리.
- cargo 40개 한도, 다중 드롭의 한도 초과 방지, 죽은 대상 중복 드롭 방지.
- 세로 적층·이동 시 적층 sway, 납품·재고·기초 자동 판매 스텁.
- 효과별 토글·reduced motion·pause/reset/focus-out 처리.
- R 재시작 시 시드와 표현 시계도 초기화하도록 수정.
- 프레임마다 바닥 스타일을 새로 생성하던 부분을 캐싱.

## 실제 검증

`godot --headless --path harvest-deck-godot --editor --import --quit` PASS.
`godot --headless --path harvest-deck-godot --script tests/run.gd` 19 checks / 0 failures.
`godot --headless --path harvest-deck-godot --quit-after 120` PASS, 런타임 오류 없음.
로그: `docs/test-output.txt`, `docs/import-output.txt`, `docs/smoke-output.txt`.

검증은 헛스윙, 명중/다수 명중, 사망 중복 방지, 적재 한도, 흔들림 상한/감쇠,
30/60/120fps 이동속도, reduced motion, pause 입력 초기화, 납품·판매 보존,
reset, 국소 정지가 전역 time_scale을 바꾸지 않는지를 포함.

## 미검증 / 한계

- CLI 실행은 복구됨. 실제 화면 렌더 확인은 아직 못 함: DISPLAY 미설정.
  로컬 dummy Xorg 기동도 listening sockets 생성 실패. 환경 권한 우회는 하지 않음.
  가능한 headless 게임 로직 검증은 계속 수행함.
- `tests/visual_smoke.gd`는 준비만 했고 실행 성공하지 않았음.
- 픽셀 완성 에셋·인간 플레이·타격감 선호도·폰 터치·Mac 런타임 미검증.
- 화면 흔들림 수치는 원본 계측치가 아닌 실험값. 영상과 동일하다고 주장하지 말 것.
- 캐릭터/과일 y-sort, 경계 충돌의 자세한 체감, 애니메이션, 루프 음향, 성능 실측 남음.
- 실제 시설 생산·손님 큐·현금 줍기·직원·저장게임 미구현. 현재 단순 판매를 완성 경영이라 하지 말 것.

## 다음

G1 플레이 검증 및 원본 수치 비교. 시각 환경이 계속 막히면 G2 재고·가공 큐 상태 분리
같은 독립 구현을 진행하고 막힌 검증은 명시적으로 남긴다. 새 기능보다 실제 버그를 우선 수정.
예약 개발은 시간당 실행 요청이며 24시간 상주 프로세스 보장이 아니다.
