extends Node2D

const Impact = preload("res://scripts/impact.gd")
const SPEED: float = 270.0
const ATTACK_INTERVAL: float = 0.105
const CAPACITY: int = 40
const BOUNDS = Rect2(40, 100, 1480, 1040)
var impact = Impact.new()
var player: Vector2 = Vector2(700, 720)
var facing: Vector2 = Vector2.UP
var velocity: Vector2 = Vector2.ZERO
var fruits: Array[Dictionary] = []
var particles: Array[Dictionary] = []
var cargo: Array[int] = []
var camera: Camera2D
var hud: Label
var status: Label
var audio: AudioStreamPlayer
var stock: int = 0
var cash: int = 0
var hits: int = 0
var cooldown: float = 0.0
var unload_clock: float = 0.0
var sale_clock: float = 0.0
var time: float = 0.0
var paused: bool = false
var feedback: bool = true
var sound_on: bool = true
var local_stop: bool = false
var drag_id: int = -1
var drag_origin: Vector2
var drag_vector: Vector2 = Vector2.ZERO
var depot: Vector2 = Vector2(680, 310)
var rng = RandomNumberGenerator.new()
var terrain_style: StyleBoxFlat

func _ready() -> void:
	rng.seed = 1742
	terrain_style = field_style()
	setup_inputs()
	camera = Camera2D.new()
	camera.position = player
	add_child(camera)
	var layer = CanvasLayer.new()
	add_child(layer)
	var panel = ColorRect.new()
	panel.color = Color(0.025, 0.055, 0.075, 0.92)
	panel.size = Vector2(960, 94)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(panel)
	hud = Label.new()
	hud.position = Vector2(22, 12)
	hud.add_theme_font_size_override("font_size", 23)
	layer.add_child(hud)
	status = Label.new()
	status.position = Vector2(22, 46)
	status.add_theme_font_size_override("font_size", 14)
	layer.add_child(status)
	audio = AudioStreamPlayer.new()
	add_child(audio)
	make_hit_sound()
	reset_run()

func setup_inputs() -> void:
	var bindings = {"left": [KEY_A, KEY_LEFT], "right": [KEY_D, KEY_RIGHT], "up": [KEY_W, KEY_UP], "down": [KEY_S, KEY_DOWN]}
	for action in bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for code in bindings[action]:
			var event = InputEventKey.new()
			event.physical_keycode = code
			InputMap.action_add_event(action, event)

func reset_run() -> void:
	rng.seed = 1742
	time = 0.0
	player = Vector2(700, 720)
	velocity = Vector2.ZERO
	facing = Vector2.UP
	cargo.clear()
	particles.clear()
	fruits.clear()
	stock = 0
	cash = 0
	hits = 0
	cooldown = 0.0
	unload_clock = 0.0
	sale_clock = 0.0
	paused = false
	drag_id = -1
	drag_vector = Vector2.ZERO
	impact.clear()
	for i in range(32):
		var kind = i % 2
		var center = Vector2(510, 690) if kind == 0 else Vector2(1020, 660)
		var home = center + Vector2(rng.randf_range(-160, 160), rng.randf_range(-170, 170))
		fruits.append({"pos": home, "home": home, "hp": 3, "kind": kind, "flash": 0.0, "respawn": 0.0, "freeze": 0.0})

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		set_paused(true)

func set_paused(value: bool) -> void:
	paused = value
	drag_vector = Vector2.ZERO
	drag_id = -1
	impact.clear()
	if is_instance_valid(camera):
		camera.offset = Vector2.ZERO

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_ESCAPE, KEY_P: set_paused(not paused)
			KEY_R: reset_run()
			KEY_1:
				impact.enabled = not impact.enabled
				impact.clear()
			KEY_2: sound_on = not sound_on
			KEY_3: feedback = not feedback
			KEY_4: local_stop = not local_stop
			KEY_M:
				impact.reduced = not impact.reduced
				impact.clear()
	if event is InputEventScreenTouch:
		if event.pressed and drag_id == -1 and not paused:
			drag_id = event.index
			drag_origin = event.position
		elif not event.pressed and event.index == drag_id:
			drag_id = -1
			drag_vector = Vector2.ZERO
	if event is InputEventScreenDrag and event.index == drag_id:
		drag_vector = ((event.position - drag_origin) / 65.0).limit_length()

func _physics_process(delta: float) -> void:
	if not paused:
		var direction = Input.get_vector("left", "right", "up", "down")
		if drag_vector.length() > 0.05:
			direction = drag_vector
		simulate(delta, direction)
	camera.position = camera.position.lerp(player, 1.0 - exp(-10.0 * delta))
	camera.offset = impact.step(delta) if not paused else Vector2.ZERO
	hud.text = "HARVEST / FEEL LAB     $%d     CARGO %d/%d     STOCK %d" % [cash, cargo.size(), CAPACITY, stock]
	status.text = "WASD / arrows / touch drag • auto-cut • return to mint pad to unload\n1 Shake %s   2 Sound %s   3 Reaction %s   4 Local-stop %s   M Reduced %s   P Pause   R Reset %s" % [impact.enabled, sound_on, feedback, local_stop, impact.reduced, "[PAUSED]" if paused else ""]
	queue_redraw()

func simulate(delta: float, direction: Vector2) -> void:
	time += delta
	velocity = direction.limit_length() * SPEED
	player += velocity * delta
	player = player.clamp(BOUNDS.position + Vector2.ONE * 20, BOUNDS.end - Vector2.ONE * 20)
	if direction.length() > 0.05:
		facing = direction.normalized()
	cooldown -= delta
	if cooldown <= 0.0:
		cooldown += ATTACK_INTERVAL
		attack()
	for f in fruits:
		f.flash = maxf(0.0, f.flash - delta)
		f.freeze = maxf(0.0, f.freeze - delta)
		if f.hp <= 0:
			f.respawn -= delta
			if f.respawn <= 0.0:
				f.hp = 3
				f.pos = f.home
		elif f.freeze <= 0.0:
			f.pos = f.pos.lerp(f.home + Vector2(sin(time * 2.0 + f.home.x) * 7, cos(time * 2.5 + f.home.y) * 5), 1.0 - exp(-7.0 * delta))
	for i in range(particles.size() - 1, -1, -1):
		var p = particles[i]
		p.life -= delta
		p.pos += p.vel * delta
		p.vel *= exp(-4.0 * delta)
		if p.life <= 0.0:
			particles.remove_at(i)
	if player.distance_to(depot) < 85 and not cargo.is_empty():
		unload_clock += delta
		while unload_clock >= 0.04 and not cargo.is_empty():
			unload_clock -= 0.04
			cargo.pop_back()
			stock += 1
	else:
		unload_clock = 0.0
	sale_clock += delta
	while sale_clock >= 0.7:
		sale_clock -= 0.7
		if stock > 0:
			stock -= 1
			cash += 5

func attack() -> int:
	if cargo.size() >= CAPACITY:
		return 0
	var count = 0
	var killed = false
	for f in fruits:
		if f.hp <= 0 or cargo.size() >= CAPACITY:
			continue
		var diff: Vector2 = f.pos - player
		if diff.length() > 100 or (diff.length() > 28 and facing.dot(diff.normalized()) < 0.1):
			continue
		f.hp -= 1
		count += 1
		hits += 1
		var dead: bool = f.hp <= 0
		impact.hit(dead)
		if feedback:
			f.flash = 0.055
			f.pos += diff.normalized() * 7
		if local_stop:
			f.freeze = 0.025
		burst(f.pos, f.kind, dead)
		if dead:
			killed = true
			f.respawn = 5.0
			for j in range(mini(3, CAPACITY - cargo.size())):
				cargo.append(f.kind)
	if count > 0 and sound_on and is_instance_valid(audio):
		audio.pitch_scale = 0.78 if killed else rng.randf_range(1.0, 1.12)
		audio.play()
	return count

func burst(at: Vector2, kind: int, dead: bool) -> void:
	for i in range(13 if dead else 5):
		var v = Vector2.RIGHT.rotated(rng.randf() * TAU) * rng.randf_range(40, 220)
		particles.append({"pos": at, "vel": v, "life": rng.randf_range(0.15, 0.4), "kind": kind})

func make_hit_sound() -> void:
	var wave = AudioStreamWAV.new()
	wave.format = AudioStreamWAV.FORMAT_16_BITS
	wave.mix_rate = 22050
	var bytes = PackedByteArray()
	bytes.resize(2205 * 2)
	for i in range(2205):
		var t = float(i) / 22050.0
		var sample = (sin(TAU * (160 * t - 420 * t * t)) * 0.65 + rng.randf_range(-0.35, 0.35)) * exp(-t * 48) * 0.35
		bytes.encode_s16(i * 2, int(sample * 32767))
	wave.data = bytes
	audio.stream = wave

func _draw() -> void:
	draw_rect(Rect2(-2000, -2000, 5500, 5500), Color("315953"))
	draw_style_box(terrain_style, BOUNDS)
	for x in range(80, 1500, 64):
		for y in range(140, 1120, 64):
			draw_line(Vector2(x, y), Vector2(x + 5, y - 7), Color(0.4, 0.65, 0.51, 0.27), 2)
	draw_circle(Vector2(510, 690), 225, Color(0.18, 0.37, 0.28, 0.3))
	draw_circle(Vector2(1020, 660), 225, Color(0.45, 0.39, 0.2, 0.25))
	draw_rect(Rect2(520, 190, 320, 72), Color("193a3e"))
	draw_rect(Rect2(530, 180, 300, 64), Color("ecbd68"))
	draw_circle(depot, 82, Color(0.42, 0.9, 0.72, 0.25))
	draw_arc(depot, 82, 0, TAU, 48, Color("85e8b3"), 3)
	var font = ThemeDB.fallback_font
	draw_string(font, Vector2(554, 220), "JUICE / DROP ZONE", HORIZONTAL_ALIGNMENT_LEFT, -1, 21, Color("183b38"))
	for i in range(5):
		var p = Vector2(570 + i * 52, 135 - sin(time * 1.4 + i) * 2)
		draw_circle(p, 13, Color("f1d8b4"))
		draw_rect(Rect2(p + Vector2(-13, 8), Vector2(26, 22)), Color("7799b3"))
	for f in fruits:
		if f.hp > 0:
			draw_fruit(f.pos, f.kind, 24, f.flash > 0 and feedback)
			if f.hp < 3:
				draw_rect(Rect2(f.pos + Vector2(-20, -36), Vector2(40, 4)), Color("233635"))
				draw_rect(Rect2(f.pos + Vector2(-20, -36), Vector2(f.hp * 13.3, 4)), Color("ffe3a0"))
	for p in particles:
		draw_circle(p.pos, 3.5, Color("f9796d") if p.kind == 0 else Color("ffd36a"))
	draw_set_transform(player + Vector2(0, 8), 0, Vector2(1, 0.45))
	draw_circle(Vector2.ZERO, 24, Color(0.02, 0.08, 0.07, 0.4))
	draw_set_transform(Vector2.ZERO)
	var bob = sin(time * 19) * 2 if velocity.length() > 1 else 0.0
	for i in range(cargo.size()):
		var sway = sin(time * 7 - i * 0.18) * minf(i * 0.3, 8.0) if velocity.length() > 1 else 0.0
		draw_fruit(player + Vector2(-13 + sway, -25 - i * 5.0), cargo[i], 11, false)
	draw_line(player + Vector2(-9, 5), player + Vector2(-10, 17 + bob), Color("202d36"), 10)
	draw_line(player + Vector2(9, 5), player + Vector2(10, 17 - bob), Color("202d36"), 10)
	draw_circle(player + Vector2(0, -9 + bob), 19, Color("253842"))
	draw_circle(player + Vector2(0, -25 + bob), 13, Color("f3d5ae"))
	draw_arc(player + Vector2(0, -28 + bob), 12, PI, TAU, 12, Color("764732"), 8)
	var saw_start = player + facing * 19 + Vector2(0, -6)
	var saw_end = saw_start + facing * 48
	var jiggle = facing.orthogonal() * sin(time * 90) * 1.6
	draw_line(saw_start, saw_end + jiggle, Color("162f35"), 20)
	draw_line(saw_start, saw_end + jiggle, Color("dce7d8"), 13)
	draw_circle(saw_start, 13, Color("eaa746"))
	if cargo.size() >= CAPACITY:
		draw_string(font, player + Vector2(-35, 45), "FULL! UNLOAD", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("ffe9a0"))

func draw_fruit(at: Vector2, kind: int, radius: float, flash: bool) -> void:
	draw_circle(at + Vector2(0, radius * 0.22), radius, Color("203e35"))
	draw_circle(at, radius - 2, Color.WHITE if flash else (Color("74bc68") if kind == 0 else Color("edb950")))
	if kind == 0:
		draw_arc(at, radius * 0.65, -1.0, 1.0, 10, Color("3a8754"), 4)
	else:
		draw_line(at + Vector2(-7, -radius + 2), at + Vector2(0, -radius - 10), Color("86ba64"), 5)
	if radius > 15:
		draw_circle(at + Vector2(-7, 0), 3, Color("17382f"))
		draw_circle(at + Vector2(7, 0), 3, Color("17382f"))

func field_style() -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = Color("4d826b")
	style.border_color = Color("23493f")
	style.set_border_width_all(12)
	style.set_corner_radius_all(45)
	return style
