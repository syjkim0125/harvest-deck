extends SceneTree

const Game = preload("res://scripts/game.gd")
const Impact = preload("res://scripts/impact.gd")
var checks: int = 0
var failures: int = 0

func _initialize() -> void:
	call_deferred("run")

func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(label)
	print("PASS " if ok else "FAIL ", label)

func fixture(game, hp: int = 3) -> void:
	game.fruits.clear()
	game.cargo.clear()
	game.player = Vector2(700, 700)
	game.facing = Vector2.RIGHT
	game.fruits.append({"pos": Vector2(755, 700), "home": Vector2(755, 700), "hp": hp, "kind": 0, "flash": 0.0, "respawn": 0.0, "freeze": 0.0})
	game.impact.clear()

func run() -> void:
	var g = Game.new()
	root.add_child(g)
	g.set_physics_process(false)
	g.sound_on = false
	fixture(g)
	g.facing = Vector2.LEFT
	check(g.attack() == 0 and g.impact.trauma == 0, "whiff has no damage or shake")
	g.facing = Vector2.RIGHT
	check(g.attack() == 1 and g.fruits[0].hp == 2 and g.impact.trauma > 0, "each confirmed hit produces feedback")
	g.attack()
	g.attack()
	check(g.cargo.size() == 3 and g.fruits[0].hp == 0, "kill awards three items")
	check(g.attack() == 0 and g.cargo.size() == 3, "dead target cannot duplicate drops")
	fixture(g, 1)
	g.cargo.resize(39)
	g.cargo.fill(0)
	g.attack()
	check(g.cargo.size() == 40, "multi-drop respects capacity")
	var hp = g.fruits[0].hp
	check(g.attack() == 0 and g.fruits[0].hp == hp, "full bag prevents cutting")
	fixture(g)
	g.fruits.append(g.fruits[0].duplicate(true))
	check(g.attack() == 2, "one pulse can cut multiple targets")
	for i in range(100):
		g.impact.hit()
	check(g.impact.trauma <= 1.0 and g.impact.step(0.0).abs().x <= 8, "crowd impact saturates")
	for fps in [30, 60, 120]:
		var fx = Impact.new()
		fx.hit(true)
		for i in range(fps):
			fx.step(1.0 / fps)
		check(is_zero_approx(fx.trauma), "shake returns to zero at %dfps" % fps)
		fixture(g)
		g.fruits.clear()
		var start: Vector2 = g.player
		for i in range(fps):
			g.simulate(1.0 / fps, Vector2.RIGHT)
		check(absf(g.player.x - start.x - 270) < 0.02, "movement speed at %dfps" % fps)
	fixture(g)
	g.impact.reduced = true
	g.attack()
	check(g.impact.step(0.01) == Vector2.ZERO and g.fruits[0].hp == 2, "reduced motion preserves damage")
	g.impact.reduced = false
	g.set_paused(true)
	check(g.impact.trauma == 0 and g.camera.offset == Vector2.ZERO and g.drag_id == -1, "pause clears impact and touch")
	g.reset_run()
	g.fruits.clear()
	g.cargo.assign([0, 1, 0])
	g.player = g.depot
	for i in range(180):
		g.simulate(1.0 / 60.0, Vector2.ZERO)
	check(g.cargo.is_empty() and g.stock == 0 and g.cash == 15, "delivery and sale conserve harvested items")
	g.reset_run()
	check(g.cargo.is_empty() and g.cash == 0 and g.stock == 0 and g.hits == 0 and g.impact.trauma == 0, "reset clears run state")
	fixture(g)
	g.local_stop = true
	g.attack()
	check(g.fruits[0].freeze > 0 and Engine.time_scale == 1.0, "local stop does not slow simulation clock")
	g.queue_free()
	await process_frame
	print("RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
