Godot v0.7.9 runtime comparison before generated fruit art. Open project.godot. Runtime source only.
