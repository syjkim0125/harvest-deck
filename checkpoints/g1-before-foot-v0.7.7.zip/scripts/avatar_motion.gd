extends RefCounted
## Presentation only: actual travelled distance drives gait, confirmed hits drive recoil.
const STRIDE: float = 72.0
const STANCE: float = 0.5
const KICK_SECONDS: float = 0.075
const KICK_UNITS: float = 2.5
var distance: float = 0.0
var walk_weight: float = 0.0
var hit_age: float = KICK_SECONDS

func step(delta: float, displacement: Vector2) -> void:
	distance = fposmod(distance + displacement.length(), STRIDE)
	walk_weight = 1.0 if displacement.length() > 0.000001 else walk_weight * exp(-18.0 * maxf(delta, 0.0))
	hit_age = minf(KICK_SECONDS, hit_age + maxf(delta, 0.0))

func confirmed_hit() -> void:
	hit_age = 0.0

func clear_hit() -> void:
	hit_age = KICK_SECONDS

func reset() -> void:
	distance = 0.0
	walk_weight = 0.0
	clear_hit()

func kick() -> float:
	return KICK_UNITS * (1.0 - hit_age / KICK_SECONDS)

func bob(reduced: bool) -> float:
	return 0.0 if reduced else -absf(sin(distance / STRIDE * TAU)) * 1.5 * walk_weight

func foot(index: int, facing: Vector2, reduced: bool) -> Dictionary:
	var phase = fposmod(distance / STRIDE + index * 0.5, 1.0)
	var along: float
	var lift = 0.0
	var planted = phase < STANCE
	if planted:
		# For straight travel this cancels the body's translation during stance.
		along = STRIDE * 0.25 - phase * STRIDE
	else:
		var swing = (phase - STANCE) / (1.0 - STANCE)
		along = lerpf(-STRIDE * 0.25, STRIDE * 0.25, swing)
		lift = 0.0 if reduced else sin(swing * PI) * 7.0
	var side = facing.orthogonal() * (-9.0 if index == 0 else 9.0)
	return {"position": Vector2(0, 15) + side + facing * along * walk_weight - Vector2(0, lift * walk_weight), "planted": planted}
