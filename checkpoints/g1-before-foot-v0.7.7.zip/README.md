Godot v0.7.7 comparison source before foot-anchor changes. Open project.godot. Runtime source only; regression suites remain in the current project.
