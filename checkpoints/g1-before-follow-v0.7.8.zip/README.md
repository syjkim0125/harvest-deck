Godot v0.7.8 runtime comparison before follow-cadence fix. Open project.godot. Older checkpoint archives and tests are omitted.
