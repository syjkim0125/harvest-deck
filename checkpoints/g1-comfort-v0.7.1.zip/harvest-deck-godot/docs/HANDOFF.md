# Current: v0.7.1 — movement / comfort

과일 해금v0.7 보존. 이동360/s, 비누적 최대1.5px/66.7ms, M키OFF.
docs/FEEL_TUNING.md 참고. 원본100% 일치 미완료.
main은v0.6이며 Github 쓰기403/브라우저 앱설정 차단으로 업로드·배포 미완료.
다음 실행은 main과 이ZIP을 병합한 뒤 검증·배포하며 G1을 우선한다.

---

# Handoff — v0.7 / 2026-11-17 KST

## 기준과 동시 변경 보호
Library libfile_e5fb49d15230819192d425860e2c9edd를 새로 가져옴.
입력 current_version_number=5, SHA256 91c8eb16095ca6c1c761809b58e36906e7bd09c8737dffcaa80b61698a82ceb0.
같은 ZIP에 expected_current_version=5로 교체하며 충돌 시 덮어쓰지 않는다.
checkpoints/g1-v0.1.zip 유지, 두 구역 모두 열린 이전 버전은 checkpoints/g2-v0.6.zip 추가.
이번 기준 ZIP에는 웹 export 설정이 없다. 별도 저장소/웹 배포 작업과 합치거나 배포 성공을 주장하지 않음.
Sites 비교물/저장소 변경 없음. 다음에 저장소 작업 시 최신 remote를 읽고 별도로 변경 통합해야 함.

## 실제 구현
- 노란 과일(kind1) 구역을 회수 지갑 $50로 해금. 기본 녹색(kind0)은 항상 열림.
- G키/CanvasLayer 버튼/호박색 패드(1020,440), 반경80 미만에서 구매.
- 비용은 production.spent_cash에 기록, 미회수대금·부족금액·pause·먼거리·중복 구매 방지.
- 잠긴 과일은 표시/절삭/보상/재생성 시계 대상에서 제외. 해금 시 원래 시드 위치 그대로 활성화.
- 생산 모델 deposit은 이미 보유한 유효 kind0/1을 받는다. 해금은 수확 권한이며 기존 재고를 몰수하는 규칙이 아니다.
- 수확→납품→가공→판매→회수에서 kind1 및 총량 보존, reset은 해금/비용 포함 새 게임으로 복구.
- 녹색 과일 12개 판매→현금60 회수→해금50 구매→잔액10 검증. 직원/강화 구매 선행 필수 아님.
- 버그 수정: 3줄 status Label 실제 최소높이66으로 y46..112인데 기존 버튼 y79부터 겹침.
  버튼 y116/HUD150으로 분리. 새 검사 최초 114개 중1개실패(첫 y108안), 실제 높이 확인 후 수정하여 모두 통과.
  늘어난 HUD에 맞춰 상점 카메라 수직여백150→180. 기존 고객 머리/응대 가장자리 검사 유지.

## 명령과 결과
프로젝트 루트에서 Godot4.6.3:
- godot --headless --path . --editor --import --quit : PASS
- godot --headless --path . --script tests/run.gd : 114 checks / 0 failures
- godot --headless --path . --script tests/feel_replay.gd : 5조건 실행 완료
- godot --headless --path . --quit-after 120 : PASS
로그 docs/import-output.txt,test-output.txt,replay-output.txt,smoke-output.txt.
기존99개를 변경 전/해금 구현 후 통과 확인. 신규15개는 잠금/비용/초기화/생산연결/HUD 배치.
5조건 모두 18초/명중38/재고26/판매4/회수20. 흔들림 OFF0, ON최대벡터9.153px.
이전 명중39에서38로 감소: 잠긴 kind1의 경계1타격 제외. 수확/판매/회수 결과 동일.
동일 효과 조건끼리 비교하며 이전 버전과 공격 수를 억지로 동일하게 맞추지 않음.

## 실제 표시와 미검증
이번 UI는 기존 v0.6 창이 열린 상태. 파일 관리자에서 새 run07 프로젝트 경로 열기를 시도했으나
표시 상태가 /workspace에 머물렀고 새 Godot 프로젝트 로드/실행을 확인하지 못함.
따라서 v0.7 실제 창 해금/버튼 겹침 해소를 확인했다고 주장하지 않음.
키/버튼은 코드로 연결되었으며 구매 함수와 상태/HUD 경계는 자동 검증.
headless 머신 DISPLAY 미설정, xvfb-run 없음. 이전 GUI 장애를 이유로 개발 중단하지 않음.
원본 이번 추가 측정 없음. 청음·주관 손맛·폰/Mac/GPU성능·원본 동등성 미검증.
테스트 수는 손맛의 증명이 아님. 고정75초실패/재고초기화 규칙 추가 없음.

## 다음
1. 최신 ZIP 가드 확인. v0.7 새 프로젝트를 실제 창에서 열어 현금50 회수→G/버튼 구매→노란 과일 수확/납품 확인.
2. G1 원본30fps 다구간 추적/절삭 주기/카메라 추적과 진동 분리. 청음·동일 경로 사람 평가 필요.
3. G2 구현 목록은 해금까지 연결했으나 새 UI 플레이 확인 전 IN_PROGRESS 유지.
4. G3 전환 전 기본형 checkpoints/g2-v0.6.zip 보존. G1 미검증을 DONE으로 바꾸지 않음.
